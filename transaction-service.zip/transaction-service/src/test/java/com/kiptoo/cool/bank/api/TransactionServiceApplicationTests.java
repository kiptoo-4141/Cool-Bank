package com.kiptoo.cool.bank.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransactionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
